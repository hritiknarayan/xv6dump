#include<iostream>
#include<vector>
#include<queue>
#include<array>

using namespace std;

struct matrix{
	array<array<int,3>,3> tm;
	vector<char> p;
};

typedef queue<matrix> q;



int right(matrix& m1, q& q1, int row,int col){
	if(row==2)
		return 1;

	else{
		matrix m=m1;
		m.tm[row][col]=m.tm[row][col+1];
		m.tm[row][col+1]=0;
		m.p.push_back('r');
		q1.push(m);
		return 0;
	}
}

int left(matrix& m1, q& q1, int row,int col){
	if(row==0)
		return 1;

	else{
		matrix m=m1;
		m.tm[row][col]=m.tm[row][col-1];
		m.tm[row][col-1]=0;
		m.p.push_back('l');
		q1.push(m);
		return 0;
	}
}


int up(matrix& m1, q& q1, int row,int col){
	if(row==0)
		return 1;

	else{
		matrix m=m1;
		m.tm[row][col]=m.tm[row-1][col];
		m.tm[row-1][col]=0;
		m.p.push_back('u');
		q1.push(m);
		return 0;
	}
}

int down(matrix& m1, q& q1, int row,int col){
	if(row==2)
		return 1;

	else{
		matrix m=m1;
		m.tm[row][col]=m.tm[row+1][col];
		m.tm[row+1][col]=0;
		m.p.push_back('d');
		q1.push(m);
		return 0;
	}
}



int check(matrix& m1, matrix& m2){

	int a=0;
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			if(m1.tm[i][j]!=m2.tm[i][j])
				a=1;}}
	if(a==0)
		return 1;
	if(a==1)
		return 0;
}


void checkshift(matrix& m1,q& q1){

	matrix m=q1.front();
	if(check(m,m1)){
		for(char c:m.p){
			cout<<c<<',';
		}
		return;
		}

		else{
			q1.pop();
			int row, col;
			int f=0;
			
			for(int i=0;i<3;i++){
				for(int j=0;j<3;j++){
					if(m.tm[i][j]==0){
					row=i;
					col=j;
					f=1;
					break;
					}
					}
					if(f==1)
						break;
					}
					up(m,q1,row,col);
					down(m,q1,row,col);
					right(m,q1,row,col);
					left(m,q1,row,col);
					}
			checkshift(m1,q1);
}


					
int main(){

	matrix ini;
	matrix fin;
	

	int n=1;
	
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			ini.tm[i][j]=n;
			fin.tm[i][j]=n;
			n++;
			}}

	ini.tm[2][2]=0;
	
	fin.tm[2][0]=7;
	fin.tm[2][2]=8;
	fin.tm[2][1]=0;

	q q1;
	q1.push(ini);
	checkshift(fin,q1);
	return 0;
}



