#include<iostream>
 
using namespace std;
 

int max(int a, int b)
{
	return (a > b)? a:b;
}
 

int FindMaxCrossingSum(int arr[], int low, int mid, int high)
{
	
	int sum = 0;
	int leftsum = -1;
	for (int i = mid; i >= low; i--)
	{
		sum = sum + arr[i];
		if (sum > leftsum)
			leftsum = sum;
	}
 
	
	sum = 0;
	int rightsum = -1;
	for (int i = mid+1; i <= high; i++)
	{
		sum = sum + arr[i];
		if (sum > rightsum)
			rightsum = sum;
    }
 
	
	return leftsum + rightsum;
}
 

int FindMaxSubArraySum(int arr[], int low, int high)
{
	int mid;
	
	if (low == high)
		return arr[low];
 
	
	mid = (low + high)/2;

	int a;
	int b;
	int c;
	int d;

	a=FindMaxSubArraySum(arr,low,mid);
	b=FindMaxSubArraySum(arr,mid+1,high);
	c=max(a,b);
	d=max(c,FindMaxCrossingSum(arr,low,mid,high));
 
	
	return d;
}

int BruteMaxSumSubArray( int * a, int n)
{
    int MaxSum = a[0];
    int MaxSumStart = 0, MaxSumEnd = 0;

    for( int i = 1; i < n; i++)
    {
        int tempSum = 0; 
        int j = i;
        while(j>=0)
        {
            tempSum += a[j];
            if ( tempSum > MaxSum )
            {
                MaxSum = tempSum;
                MaxSumStart = j;
                MaxSumEnd = i; 
            }
            j--;
        }
    }

    return MaxSum;
}
 
int main()
{
	int n, i;
	n=10000;
	int a[n];

	int sum=-5000;

	for(i=0;i<n;i++){

		a[i]=sum;
		sum+=1;
	}
    
	
 
	
	cout<<"Maximum Subarray (sum): "<<BruteMaxSumSubArray(a,n);
 
	return 0;
}
